package com.example.equipment.web;


import com.example.equipment.model.Equipment;
import com.example.equipment.repository.EquipmentRepository;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;


/**
* Bean JSF responsável pela interface de equipamentos.
* Escopo: ViewScoped para manter estado durante interação da página.
*/
@Named
@ViewScoped
public class EquipmentBean implements Serializable {


private static final long serialVersionUID = 1L;


@Inject
private EquipmentRepository repo;


private List<Equipment> equipments;
private Equipment selected;
private Equipment newEquipment;


@PostConstruct
public void init() {
equipments = repo.findAll();
newEquipment = new Equipment();
}


public void refresh() {
equipments = repo.findAll();
}


// CREATE
public void create() {
repo.create(newEquipment);
newEquipment = new Equipment();
refresh();
}


// UPDATE
public void save() {
if (selected != null) {
repo.update(selected);
refresh();
}
}


// DELETE
public void delete() {
if (selected != null && selected.getId() != null) {
repo.delete(selected.getId());
selected = null;
refresh();
}
}


// getters/setters
public List<Equipment> getEquipments() { return equipments; }
public Equipment getSelected() { return selected; }
public void setSelected(Equipment selected) { this.selected = selected; }
public Equipment getNewEquipment() { return newEquipment; }
public void setNewEquipment(Equipment newEquipment) { this.newEquipment = newEquipment; }
}