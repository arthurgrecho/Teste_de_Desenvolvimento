package com.example.equipment.model;


import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;


/**
* Entidade JPA que representa um Equipamento.
* Campos: id, nome, descricao, dataAquisicao, valor, validade
*/
@Entity
@Table(name = "equipments")
public class Equipment implements Serializable {


private static final long serialVersionUID = 1L;


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@Column(nullable = false, length = 150)
private String nome;


@Column(length = 1000)
private String descricao;


@Column(name = "data_aquisicao")
private LocalDate dataAquisicao;


@Column(precision = 15, scale = 2)
private BigDecimal valor;


@Column(name = "validade")
private LocalDate validade;


// Construtor sem argumento para JPA
public Equipment() { }


// Getters e setters
public Long getId() { return id; }
public void setId(Long id) { this.id = id; }


public String getNome() { return nome; }
public void setNome(String nome) { this.nome = nome; }


public String getDescricao() { return descricao; }
public void setDescricao(String descricao) { this.descricao = descricao; }


public LocalDate getDataAquisicao() { return dataAquisicao; }
public void setDataAquisicao(LocalDate dataAquisicao) { this.dataAquisicao = dataAquisicao; }


public BigDecimal getValor() { return valor; }
public void setValor(BigDecimal valor) { this.valor = valor; }


public LocalDate getValidade() { return validade; }
public void setValidade(LocalDate validade) { this.validade = validade; }
}