package com.example.equipment.repository;


import com.example.equipment.model.Equipment;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;


@Stateless
public class EquipmentRepository {


@PersistenceContext(unitName = "EquipPU")
private EntityManager em;


public Equipment create(Equipment equipment) {
em.persist(equipment);
return equipment;
}


public Equipment update(Equipment equipment) {
return em.merge(equipment);
}


public void delete(Long id) {
Equipment e = em.find(Equipment.class, id);
if (e != null) {
em.remove(e);
}
}


public Equipment find(Long id) {
return em.find(Equipment.class, id);
}


public List<Equipment> findAll() {
TypedQuery<Equipment> q = em.createQuery("SELECT e FROM Equipment e ORDER BY e.nome", Equipment.class);
return q.getResultList();
}
}