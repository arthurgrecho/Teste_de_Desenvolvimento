package br.com.skeleton.web;


public class ApplicationConfig {

}
